from cattrs.dispatch import FunctionDispatch, MultiStrategyDispatch

__all__ = ["FunctionDispatch", "MultiStrategyDispatch"]
